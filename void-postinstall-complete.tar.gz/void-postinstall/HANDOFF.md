# Handoff: void-postinstall rewrite

**Status (2026-10-11):** implementation complete. The package contains the original audit, the guided installer, PipeWire/session/update tools, 15 WM rices, 15 generated wallpapers, and an operating guide. Validation is recorded in the delivery summary; it must not be represented as a live Void Linux runtime test unless it was actually run there.

## Scope completed

- Corrected the original script’s package names, hardware detection, transaction ordering, login-manager timing, networking handoff, and other issues documented in `AUDIT.md`.
- Configured PipeWire/WirePlumber, PulseAudio compatibility, ALSA routing, runtime/session bus setup, seatd groups, and DE autostart.
- Added sessions and custom rices for the Void-packaged tiling WMs. Hyprland uses `sofijacom/hyprland-void`, its pinned signing key, low repository priority, repolocks, and the `void-update` shlib guard.
- Added `README.md` with install/update instructions, key bindings, audio diagnostics, and how to undo the session `noextract` rules.

## Layout

```text
install.sh
lib/                 installer, package, service, hardware, session and audio logic
files/bin/           void-session, void-pipewire, void-audio-check, void-update,
                     void-rice and rice
files/xbps-keys/     pinned Hyprland repository signing key
rices/palettes/      15 color palettes
rices/wallpapers/    15 2560x1440 JPEG wallpapers
rices/common/        shared terminal, launcher, notification and bar templates
rices/wm/            WM configs, manifests and dwm/FrankenWM build patches
AUDIT.md             audit of the original script
README.md            installation and usage guide
```

The installer asks every question before changing the machine. `--dry-run` previews work; `--rices-only` reapplies rices for installed sessions. It does not commit or push repository changes.

## Operational notes

- Use `void-audio-check` from a normal graphical session after installation.
- Use `void-update` for system updates when packages from Hyprland’s third-party repository are installed. Its own temporary holds are released on the next run.
- Under seatd, the suspend menu calls `sudo -n zzz`; a limited sudoers rule is installed for that helper.
- If a source build for `dwm` or `FrankenWM` fails, the installed Void package is the session fallback.
- `/etc/xbps.d/90-void-postinstall.conf` masks package-owned upstream session files. Remove it and force-reinstall the owning package to restore one of those files; see `README.md`.

## Validation performed

- Bash syntax passed for all 19 shell scripts.
- Rendered all 15 rices into a fake root; no unresolved `@@...@@` placeholders remained.
- Python syntax compilation passed for the rendered Qtile config; all six generated Waybar JSONC files parsed with JSON5.
- Verified all 15 wallpapers are 2560×1440 JPEGs.
- The installer completed a mocked Sway + greetd install into a fake root. `xbps-install`, account/ownership changes, and symlink creation were mocked; no host packages or services were changed. A separate dry-run walkthrough also completed.

## Not run

This Windows host has no ShellCheck, sway/i3/awesome validators, Lua compiler, jq, Qtile runtime, Niri KDL parser, Wayfire/other WM binaries, Xvfb, or Linux build toolchain. The dwm/FrankenWM source builds and graphical smoke tests were not run. No real Void Linux installation was available, so all Linux runtime behavior is code-reviewed rather than platform-tested.
