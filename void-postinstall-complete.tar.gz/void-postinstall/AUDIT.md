# Audit of the original `void-postinstall.sh`

Checked on 2026-10-11 against:

- **The Void Handbook** (the PDF you attached, printed today from docs.voidlinux.org)
- **void-packages `master`** (commit `f485811`, 2026-10-11): every package name the script uses was checked against `srcpkgs/`
- **hyprland-void `repository-x86_64-glibc`**: the live repodata index was parsed for `shlib-requires`, `shlib-provides` and `run_depends`
- **xbps source** (`void-linux/xbps@c5f41d5`): hold, repolock and shlib-check behaviour

Line numbers refer to the original file.
**Severity:** 🔴 breaks the install or audio · 🟠 wrong per handbook or repo, or a silent failure · 🟡 robustness/UX · ⚡ efficiency

---

## 0. Before anything else

| # | Sev | Line | Finding |
|---|-----|------|---------|
| 0.1 | 🔴 | all | **The file you sent has Windows CRLF line endings.** On Linux the shebang becomes `bash\r` (`env: 'bash\r': No such file or directory`), `set -euo pipefail\r` fails, and no heredoc terminator (`EOF\r`) ever matches. If the copy on your Void machine is the same, it never ran. Fix: `sed -i 's/\r$//' void-postinstall.sh`, or set your editor to LF. With CR stripped, `shellcheck` reports nothing, so every other problem below is semantic. |

## 1. Audio: why it "never works"

| # | Sev | Line | Finding |
|---|-----|------|---------|
| 1.1 | 🔴 | 851–854 | **PipeWire is never started.** The script only prints a warning. The handbook says pipewire must be launched by the session, through DE autostart, XDG autostart (`/etc/xdg/autostart`) or the WM's startup. GNOME, KDE, XFCE, MATE, Cinnamon, LXQt, i3, Sway, River and Wayfire all came up with no sound server. Only the Hyprland branch started it. |
| 1.2 | 🔴 | 344–355, 404 | **No D-Bus session bus for WM sessions.** The handbook says PipeWire *requires* a user session bus, and WMs started from a TTY must use `dbus-run-session`. The script tells you to run `sway`, `river`, `wayfire` and `Hyprland` bare. Without a bus, WirePlumber, Bluetooth audio and portals all fail. |
| 1.3 | 🔴 | 272–277 | **The seatd path has no `XDG_RUNTIME_DIR` and no device access.** Without elogind nothing creates `/run/user/$UID`, and PipeWire dies with `no runtime dir found` (handbook, *Common errors*). Without elogind you must also be in the `audio` and `video` groups; otherwise you get the "Only a dummy output" case. The script only printed a hint about `_seatd`. |
| 1.4 | 🔴 | 391–392 | **WirePlumber starts twice under Hyprland.** `10-wireplumber.conf` (L837) already makes `pipewire` launch WirePlumber, and the config also runs `exec-once = wireplumber`. Two session managers fight over the same nodes. |
| 1.5 | 🟠 | 830 | **No ALSA routing.** `alsa-pipewire` plus the two `/etc/alsa/conf.d` links from the handbook are missing, so ALSA-only programs bypass PipeWire and grab the card exclusively. |
| 1.6 | 🟠 | — | **No `sof-firmware` or `alsa-ucm-conf`.** Most Intel laptops since about 2019 (SOF DSP) show no sound card at all without them. This is the classic "no audio on Void" laptop case. |
| 1.7 | 🟠 | 823–825 | `xbps-remove -Ry pulseaudio` aborts the whole script under `set -e` when anything still depends on pulseaudio. If pulseaudio is kept for that reason, its autospawn still races `pipewire-pulse` for the socket. |
| 1.8 | 🟠 | 836–848 | `[ ! -e link ] && ln -s` without `-f`: a dangling symlink makes `-e` false, then `ln` fails with "File exists", and `set -e` kills the run. |
| 1.9 | 🟡 | — | No `rtkit` (PipeWire logs RT errors and can xrun under load). No `pavucontrol`/`wpctl` integration. Nothing to diagnose a broken setup. |
| 1.10 | 🟠 | — | **Logout leaves PipeWire running, tied to a dead bus.** On the next login an "already running" pipewire blocks a fresh one, and Bluetooth/MPRIS break until reboot. |

## 2. Install-breaking problems

| # | Sev | Line | Finding |
|---|-----|------|---------|
| 2.1 | 🔴 | 363 | **The Hyprland install fails today.** `hyprpolkitagent` (and `hyprland-qt-support`/`hyprland-guiutils`) in hyprland-void require `libQt_6_PRIVATE_API.6.11.1`. Void `master` now ships `qt6-core-6.11.2` (`common/shlibs`: `libQt_6_PRIVATE_API.6.11.2`). Everything is in **one** `xbps-install` call, so the whole transaction (Hyprland included) aborts with *unresolvable shlib*, and `set -e` ends the script. |
| 2.2 | 🔴 | 417–420 | **The display manager starts mid-script.** Linking `gdm`/`sddm`/`lightdm` into `/var/service` starts it within about 5 s. It grabs the VT while the script is still asking GPU and app questions on tty1, so the prompts vanish behind a login screen with no graphics driver installed yet. Enable it last. |
| 2.3 | 🔴 | 711–723 | **NetworkManager cuts off the network mid-run.** Removing `dhcpcd` and `wpa_supplicant` from `/var/service` stops them immediately. NM has no Wi-Fi credentials yet, so every later download (terminal, media, Steam, LibreOffice, Bluetooth, PipeWire!) fails. |
| 2.4 | 🔴 | 119 | `xbps-install -S` for the hyprland-void key is interactive. Answering *n* or hitting EOF makes xbps exit non-zero, and `set -e` aborts. The README you sent contains the key, so it can be imported non-interactively and its fingerprint checked. |
| 2.5 | 🟠 | 159, 183, 220 | Every `read` uses stdin. Run as `curl … \| sudo bash`, the prompts eat the script itself. Read from `/dev/tty`. |
| 2.6 | 🟠 | 260–279 | seatd can be combined with GNOME, KDE, GDM or SDDM, which need logind. That is a guaranteed broken login. |

## 3. Wrong or missing package names (checked against `srcpkgs/`)

`install_avail` skips unknown names with only a warning, so these fail **silently**:

| Line | Used | Reality |
|------|------|---------|
| 646 | `thunar` | Package is **`Thunar`**, so Thunar was never installed |
| 463 | `mesa-vulkan-lvp` | It's **`mesa-vulkan-lavapipe`** |
| 464 | `mesa-vdpau` | No longer exists (Void's `mesa-26.2.4` template has no VDPAU subpackage). Handbook: `libvdpau-va-gl` + `VDPAU_DRIVER=va_gl` |
| 530 | `xf86-video-vmware` | Removed from Void. VMware guests use modesetting (`open-vm-tools` for integration) |
| 520 | `mesa-nouveau-dri` | Transitional dummy that only pulls `mesa-dri` |
| 367 | `waybar` fallback | Only `Waybar` exists (harmless, but dead code) |
| 553 | `mesa-nouveau-dri-32bit` | Dummy as above; use `mesa-dri-32bit` |
| 506 | `nvidia-firmware` | Already a hard dependency of `nvidia` |

## 4. Handbook violations

| # | Sev | Line | Finding |
|---|-----|------|---------|
| 4.1 | 🟠 | 505 | **Wrong NVIDIA package for most cards.** Handbook table: Turing+ → `nvidia` (595, open modules); **Maxwell–Volta (GTX 9xx/10xx, Titan V) → `nvidia580`**; Kepler → `nvidia470`; Fermi → `nvidia390`. The script installs `nvidia` for everything, so any GTX 1060/1080 owner gets a driver that doesn't support the card. |
| 4.2 | 🟠 | 505 | `linux-headers` only matches the `linux` meta package. On `linux-lts`, `linux-mainline` or a pinned `linuxX.Y`, DKMS has no headers and the module never builds. Install `linuxX.Y-headers` for every installed kernel series. |
| 4.3 | 🟠 | 512–514 | The claim that "the Void package ships nvidia_drm.modeset in /etc/modprobe.d" is false. `/usr/lib/modprobe.d/nvidia.conf` only blacklists nouveau/nova. (On 560+ modeset defaults to on anyway. Set it explicitly for the legacy branches.) |
| 4.4 | 🟠 | 263–270 | elogind is enabled while `acpid` stays enabled. Handbook (*Power Management*): both handle lid/power keys, so closing the lid suspends twice (instant re-suspend on resume). Disable acpid when using elogind. |
| 4.5 | 🟠 | — | **No `polkit`.** Handbook: `loginctl poweroff/reboot` need polkit. There is also no polkit *agent*, so GUI privilege prompts silently fail in every WM. |
| 4.6 | 🟠 | 1.2 | No `dbus-run-session` for TTY-started WMs (see 1.2). |
| 4.7 | 🟠 | 328–329 | No fonts on the Wayland path. Handbook: "some compositors do not depend on any fonts… install a font package". River, Wayfire and Hyprland showed tofu. `wayland-protocols` (L329) is a build-time XML package, so it's dead weight. |
| 4.8 | 🟠 | 329 | `xdg-desktop-portal-wlr` is installed for GNOME, KDE and Hyprland. Each needs its own backend (`-gnome`, `-kde`, `-hyprland`) plus `-gtk` for file pickers, and `XDG_CURRENT_DESKTOP` set so `*-portals.conf` resolves. |
| 4.9 | 🟠 | 487–491 | `xf86-video-intel` is installed and the next line tells you to remove it. Handbook: DDX drivers can break newer Intel chips, and modesetting is the default. `intel-video-accel` (L483) already pulls both VA-API drivers, so L485 is redundant. |
| 4.10 | 🟠 | 547, 784 | 32-bit and Steam set is incomplete. Steam's `README.voidlinux` needs `libdrm-32bit libglvnd-32bit` too, and legacy NVIDIA uses `nvidia580/470/390-libs-32bit`. |
| 4.11 | 🟠 | 711 | NetworkManager users must be in the `network` group (handbook). Never done. |
| 4.12 | 🟠 | 813 | Bluetooth: no `rfkill unblock`, user never added to `bluetooth` (handbook). Also installed unconditionally, even with no controller. |
| 4.13 | 🟡 | 47–59 | `enable_service` only knows `/var/service`. In a chroot (handbook *Enabling Services*) it must link into `/etc/runit/runsvdir/default/`, which also works on a live system. |
| 4.14 | 🟡 | 245–246 | Handbook: xbps must update itself in a *separate* transaction. That part is right, but `-S` runs twice for nothing (see ⚡). |

## 5. Hyprland / hyprland-void

| # | Sev | Line | Finding |
|---|-----|------|---------|
| 5.1 | 🔴 | 363 | See 2.1. Qt-private-API packages are the most fragile thing in that repo. Every Qt point release on Void breaks them until hyprland-void rebuilds. Avoid them: use `polkit-gnome` and `swaybg` instead of `hyprpolkitagent` and `hyprpaper`. |
| 5.2 | 🔴 | 115 | **Repo priority and name collisions.** xbps takes a package from the **first** repository that has it, not the highest version (`bestmatching` is off by default, see `lib/rpool.c`). `/etc/xbps.d` is read **before** `/usr/share/xbps.d`. Writing the repo to `/etc/xbps.d/hyprland-void.conf` therefore makes hyprland-void the *highest-priority repo on the system*, shadowing Void wherever names collide. Today that means `lua55`/`lua55-devel` (hyprland-void's 5.5.0 shadows Void's 5.5.1), `hyprutils`, `hyprpicker` and `hyprwayland-scanner`. The repo has also carried `sdbus-cpp`, `libspng` and `glaze`. Upstream's own `hyprland-repo` template uses `/usr/share/xbps.d/99-hyprland-void.conf` (lowest priority) for this reason. Lowest priority alone isn't enough, though. Void ships `hyprutils-0.11.0` (`libhyprutils.so.10`), hyprland-void ships `0.14.1` (`.so.13`). The day Void's version passes hyprland-void's, `-Su` swaps it in and every Hypr\* binary loses `libhyprutils.so.13`. **Repolocking** the packages that came from hyprland-void closes that hole. |
| 5.3 | 🔴 | — | **No shlib protection at all.** hyprland-void binaries pin volatile Void sonames: `libre2.so.11`, `libglslang.so.16`, `libjxl.so.0.12`, `libdisplay-info.so.2`, `libicuuc.so.78`, `libtomlplusplus.so.3`, `libzip.so.5`, `libmuparser.so.2`, `libsdbus-c++.so.2`. When Void bumps one before hyprland-void rebuilds, a *system-wide* `xbps-install -Su` refuses to run. That locks you out of security updates. |
| 5.4 | 🟠 | 372 | Hyprland **0.56.1 deprecated `.conf` configs** (deprecation notice on start). 0.55+ prefers `~/.config/hypr/hyprland.lua`. |
| 5.5 | 🟠 | 393 | `exec-once = hyprpolkitagent`: the binary lives in `/usr/libexec/` (upstream CMake installs to `LIBEXECDIR`), not `$PATH`, so it silently never runs. |
| 5.6 | 🟠 | 395 | `hyprpaper` is started with no `hyprpaper.conf`, so nothing is shown. |
| 5.7 | 🟠 | 404 | Hyprland ≥ 0.53 should be launched via `start-hyprland` (crash watchdog and safe mode). The package ships it. |
| 5.8 | 🟡 | 415 | When Hyprland is declined or unsupported, the summary still says "Hyprland". |

## 6. Configs that never reach you

| # | Sev | Line | Finding |
|---|-----|------|---------|
| 6.1 | 🔴 | 372, 568, 586 | Everything goes to **`/etc/skel` only**. That is copied when a user is *created*, but void-installer creates your user *before* you run this script. Your account never gets the Hyprland, rofi or wofi configs. |
| 6.2 | 🟠 | 276, 683, 815 | All group changes (`_seatd`, `docker`, `bluetooth`) are printed as `usermod` hints and never run. Missing `audio`/`video`/`network`/`bluetooth` groups are the second big cause of "no sound" (1.3). |
| 6.3 | 🟠 | 324 | i3: "add `exec i3` to ~/.xinitrc", but the file is never created and there's no D-Bus. |
| 6.4 | 🟠 | 352–354 | River 0.3 has **no built-in keybindings**. Without `~/.config/river/init` you get a black screen you can't leave. The script never installs one. |
| 6.5 | 🟡 | 743 | Foot (Wayland-only) is offered in an X11 install. |

## 7. Detection bugs

| # | Sev | Line | Finding |
|---|-----|------|---------|
| 7.1 | 🟠 | 442 | `*ati*` matches the "ati" in "Corpor**ati**on". A Hyper-V guest ("Microsoft Corporation…") is detected as **AMD**, and so is any vendor line containing "Corporation" that isn't caught earlier. Match PCI vendor IDs (`/sys/bus/pci/devices/*/vendor`: 0x1002 AMD, 0x8086 Intel, 0x10de NVIDIA, …) instead of strings. That also removes the `pciutils` dependency. |
| 7.2 | 🟡 | 454–476 | Detection is only printed. It should **pre-select** the matching driver (Enter = accept), and pick the right NVIDIA branch from the device ID. |

## 8. ⚡ Efficiency

| # | Line | Finding |
|---|------|---------|
| 8.1 | 62–77 | `pkg_available` runs `xbps-query -R` **once per package**, about 120 calls, and each one re-opens and parses every repo index. One `xbps-query -Rs ''` call can load the whole pool into a bash associative array, making each lookup O(1). |
| 8.2 | everywhere | About 40 separate `xbps-install` transactions. Each resolves the full dependency graph again, and a failure halfway leaves a half-configured system. Collect everything, install in **one** transaction, and fall back to per-group installs only if it fails, to isolate the bad package. |
| 8.3 | 129–150 | nonfree and multilib each trigger a full `-Sy` of *all* repos. Add every repo first, then sync once. |
| 8.4 | flow | Prompts are interleaved with downloads, so you babysit a 30-minute run. Ask everything first, show a summary, then run unattended with a log file (`/var/log/void-postinstall.log`). |
| 8.5 | 427–451 | `lspci` needs `pciutils` installed first. Reading `/sys/bus/pci/devices` is instant and dependency-free. |
| 8.6 | 545–558 / 780–795 | The 32-bit library logic is duplicated for the "32-bit" and "Steam" questions. |

---

## What the rewrite does about each class

| Problem class | Fix in the new project |
|---|---|
| Audio (1.x) | `lib/audio.sh` follows the handbook (system-wide `conf.d` links, ALSA routing, firmware, rtkit). `void-pipewire` starts **exactly one** stack per session and kills stale ones from dead sessions. `void-session` provides the D-Bus bus and `XDG_RUNTIME_DIR` for every WM. XDG autostart covers full DEs. Groups are applied automatically when elogind is absent. `void-audio-check` diagnoses a running session. |
| Hyprland repo (2.1, 5.x) | Key is imported non-interactively and its fingerprint verified. The repo goes in at the **lowest** priority (`/usr/share/xbps.d/99-hyprland-void.conf`, same as upstream's `hyprland-repo` package), and the old shadowing `/etc/xbps.d/hyprland-void.conf` is removed. A minimal package set avoids Qt-private-API packages and installs in its own transaction, so a broken hyprland-void can't take the system down. Everything that came from hyprland-void is **repolocked**. `void-update` replaces `xbps-install -Su`: it dry-runs, parses `broken, unresolvable shlib` lines, **holds** exactly the packages whose update would break something, and releases those holds on the next run once hyprland-void catches up. |
| Ordering (2.2, 2.3) | All questions first. Network-service switch and DM enable happen **last**. |
| Names (3) | Every name verified against `srcpkgs/` on 2026-10-11. |
| Configs for your user (6) | The target user is detected (or created) and configs are written to their home; existing files are backed up before replacement. Later users can run `void-rice apply --installed --user NAME`. |
| Efficiency (8) | One repo-index load, one initial sync (with another only when a repository is added), one main transaction, one hyprland-void transaction, everything logged. |
